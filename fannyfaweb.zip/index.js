require('dotenv').config()
const express = require('express')
const mysql = require('mysql2')
const path = require('path')

const app = express()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())

app.use(express.static(path.join(__dirname, 'public')))

// ===== KONEKSI MYSQL ====
const db = mysql.createConnection({
  host: '127.0.0.1',
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
})


db.connect(err => {
  if (err) {
    console.error('MySQL error:', err)
    return
  }
  console.log('Terhubung ke MySQL!')
})

function requireAdmin(req, res, next) {
  if (!req.session.userId || req.session.role !== "admin") {
    return res.redirect("/auth/login");
  }
  next();
}
function isAdmin(req, res, next) {
  if (req.session.admin) return next();
  res.status(401).json({ message: 'Unauthorized' });
}


// ===== USERS =====
app.get('/users', (req, res) => {
  db.query('SELECT * FROM users', (err, results) => {
    if (err) return res.status(500).send(err)
    res.json(results)
  })
})

app.get('/admin', (req, res) => {
res.sendFile(path.join(__dirname,"public","admin.html"))
})

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;

  if (username === 'admin' && password === '12345') {
    req.session.admin = true;
    return res.json({ success: true });
  }

  res.status(401).json({ success: false });
});

// ===== PRODUCTS CRUD =====
app.post('/products', isAdmin, (req, res) => {
  const { name, description, image } = req.body;
  db.query(
    'INSERT INTO products (name, description, image) VALUES (?, ?, ?)',
    [name, description, image],
    () => res.json({ success: true })
  );
});

app.delete('/products/:id', isAdmin, (req, res) => {
  db.query('DELETE FROM products WHERE id=?', [req.params.id], () => {
    res.json({ success: true });
  });
});

app.post('/products/delete/:id', (req, res) => {
  const { id } = req.params
  db.query(
    'DELETE FROM products WHERE id = ?',
    [id],
    err => {
      if (err) return res.status(500).send(err)
      res.redirect('/')
    }
  )
})
async function login() {
  const res = await fetch("http://localhost:3000/admin/login", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: username.value,
      password: password.value
    })
  });

  if (res.ok) {
    document.getElementById("login-box").style.display = "none";
    document.getElementById("admin-panel").style.display = "block";
    loadProducts();
  } else {
    alert("Login gagal");
  }
}



// ===== SERVER =====
app.listen(3000, () => {
  console.log('Server berjalan di http://localhost:3000')
})
