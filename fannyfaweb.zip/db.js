import mysql from 'mysql';

export const db = mysql.createConnection({
    host: 'localhost',
    user: 'fannyfa-admin',       // sesuaikan username MySQL
    password: 'fanny1124',       // sesuaikan password
    database: 'users'
});

db.connect(err => {
    if (err) throw err;
    console.log('Terhubung ke MySQL!');
});
